const crypto = require('node:crypto');
const { db } = require('../db');
const { getGameByChannel } = require('./gameChannelService');
const games = require('./funGameService');
const mines = require('./minesService');
const { getCatalogItem } = require('./itemCatalogService');
const { consumeInventory, getInventoryQuantity, equipOwnedCosmetic } = require('./shopService');
const { getActiveEffect, addEffectCharge, consumeActiveEffect, insuredRefund } = require('./effectStateService');

function activateEffect(guildId, userId, itemId, effectId, { expiresAt = null, charges = 1 } = {}) {
  return db.transaction(() => {
    consumeInventory(guildId, userId, itemId, 1);
    return addEffectCharge(guildId, userId, effectId, { expiresAt, charges });
  })();
}
function useHint(guildId, channelId) {
  const channel = getGameByChannel(guildId, channelId);
  if (channel?.game !== 'vuatiengviet') throw new Error('WRONG_EFFECT_CHANNEL');
  const session = games.getVuaSession(guildId); if (!session) throw new Error('NO_ACTIVE_GAME');
  const answer = session.question.answer;
  return `🔎 Gợi ý: từ đúng bắt đầu bằng **${answer[0].toUpperCase()}**, kết thúc bằng **${answer.at(-1)}** và có **${answer.replace(/\s/g, '').length} chữ cái**.`;
}
function useSkip(guildId, channelId) {
  const channel = getGameByChannel(guildId, channelId);
  if (!channel || !['vuatiengviet', 'noitu'].includes(channel.game)) throw new Error('WRONG_EFFECT_CHANNEL');
  if (channel.game === 'vuatiengviet') {
    const result = games.skipVuaSession(guildId); if (!result) throw new Error('NO_ACTIVE_GAME');
    return `⏭️ Đã đổi câu.\n${games.vuaQuestionText(result.nextQuestion)}`;
  }
  const session = games.skipWordSession(guildId); if (!session) throw new Error('NO_ACTIVE_GAME');
  return `⏭️ Đã đổi lượt nối từ. Từ tiếp theo phải bắt đầu bằng **${session.required}**.`;
}
function useMinesDetector(guildId, userId, channelId) {
  const session = mines.getMinesByUser(guildId, userId);
  if (!session || session.channel_id !== String(channelId)) throw new Error('NO_ACTIVE_MINES');
  const state = JSON.parse(session.state_json); const hidden = state.mines.filter(cell => !state.opened.includes(cell));
  if (!hidden.length) throw new Error('NO_HIDDEN_MINE');
  return `🧭 Máy dò phát hiện **ô ${hidden[crypto.randomInt(hidden.length)] + 1} có mìn**. Chỉ mình bạn thấy thông tin này.`;
}
function useMinesSafeMap(guildId, userId, channelId) {
  const session = mines.getMinesByUser(guildId, userId);
  if (!session || session.channel_id !== String(channelId)) throw new Error('NO_ACTIVE_MINES');
  const state = JSON.parse(session.state_json); const minesSet = new Set(state.mines); const openedSet = new Set(state.opened);
  const safe = Array.from({ length: mines.CELL_COUNT }, (_, index) => index).filter(index => !minesSet.has(index) && !openedSet.has(index));
  if (!safe.length) throw new Error('NO_HIDDEN_SAFE_CELL');
  return `🗺️ Bản đồ xác nhận **ô ${safe[crypto.randomInt(safe.length)] + 1} an toàn**. Chỉ mình bạn thấy thông tin này.`;
}
function useItem({ guildId, userId, channelId, itemId }) {
  const item = getCatalogItem(itemId);
  if (!item || getInventoryQuantity(guildId, userId, itemId) < 1) throw new Error('ITEM_NOT_OWNED');
  if (item.type === 'color') { equipOwnedCosmetic(guildId, userId, item.id); return { item, message: `🎨 Đã trang bị **${item.name}**. Dùng \`/hoso\` để xem.`, ephemeral: true }; }
  if (item.effect === 'quiz_hint') { const message = useHint(guildId, channelId); consumeInventory(guildId, userId, item.id); return { item, message }; }
  if (item.effect === 'quiz_skip') { const message = useSkip(guildId, channelId); consumeInventory(guildId, userId, item.id); return { item, message }; }
  if (item.effect === 'mines_detector') { const message = useMinesDetector(guildId, userId, channelId); consumeInventory(guildId, userId, item.id); return { item, message, ephemeral: true }; }
  if (item.effect === 'mines_safe_cell') { const message = useMinesSafeMap(guildId, userId, channelId); consumeInventory(guildId, userId, item.id); return { item, message, ephemeral: true }; }
  if (item.effect === 'bet_insurance') { activateEffect(guildId, userId, item.id, 'bet_insurance', { expiresAt: Date.now() + 86_400_000 }); return { item, message: '🛡️ Đã kích hoạt hoàn 25% cho ván cược thua trắng kế tiếp, hiệu lực 24 giờ.' }; }
  if (item.effect === 'bet_insurance_plus') { activateEffect(guildId, userId, item.id, 'bet_insurance_plus', { expiresAt: Date.now() + 86_400_000 }); return { item, message: '🛡️ Đã kích hoạt hoàn 50% cho ván cược thua trắng kế tiếp, hiệu lực 24 giờ.' }; }
  if (item.effect === 'quiz_reward_boost') { activateEffect(guildId, userId, item.id, 'quiz_reward_boost', { expiresAt: Date.now() + 7 * 86_400_000 }); return { item, message: '✨ Câu trả lời đúng tiếp theo được nhân đôi thưởng, hiệu lực 7 ngày.' }; }
  if (item.effect === 'hardcore_revive') { activateEffect(guildId, userId, item.id, 'hardcore_revive'); return { item, message: '❤️ Bùa hồi sinh đã sẵn sàng cho Hardcore Run tiếp theo.' }; }
  if (item.effect === 'hardcore_chest_lock') { activateEffect(guildId, userId, item.id, 'hardcore_chest_lock'); return { item, message: '🔒 Khóa hòm đã sẵn sàng cho Hardcore Run tiếp theo.' }; }
  if (item.effect === 'season_points_boost') { activateEffect(guildId, userId, item.id, 'season_points_boost', { expiresAt: Date.now() + 7 * 86_400_000, charges: 3 }); return { item, message: '🚩 Ba ván tiếp theo nhận gấp đôi điểm mùa.' }; }
  if (item.effect === 'checkin_streak_guard') { activateEffect(guildId, userId, item.id, 'checkin_streak_guard', { expiresAt: Date.now() + 30 * 86_400_000 }); return { item, message: '📅 Thẻ sẽ tự bảo vệ chuỗi nếu bạn bỏ lỡ đúng một ngày.' }; }
  throw new Error('ITEM_NOT_USABLE');
}
module.exports = { getActiveEffect, activateEffect, consumeActiveEffect, insuredRefund, useItem };
