const { CATALOG: PROFILE_COSMETICS, DEFAULT_IDS } = require('./profileCosmeticService');

const DEFAULT_PRICE_MULTIPLIER = 100;
const shopPrice = basePrice => basePrice * DEFAULT_PRICE_MULTIPLIER;
const DEFAULT_PROFILE_ITEMS = new Set(DEFAULT_IDS);

const UTILITY_ITEMS = [
  { id: 'hint_charm', type: 'consumable', name: 'Bùa Gợi Ý', effect: 'quiz_hint', rarity: 'common', price: shopPrice(300), stackable: true, tradeable: true, description: 'Mở thêm một gợi ý trong Vua tiếng Việt.' },
  { id: 'skip_card', type: 'consumable', name: 'Thẻ Đổi Câu', effect: 'quiz_skip', rarity: 'common', price: shopPrice(500), stackable: true, tradeable: true, description: 'Đổi câu Vua tiếng Việt hoặc lượt Nối từ hiện tại.' },
  { id: 'reward_booster', type: 'consumable', name: 'Bùa Nhân Đôi Thưởng', effect: 'quiz_reward_boost', rarity: 'rare', price: shopPrice(1000), stackable: true, tradeable: true, description: 'Nhân đôi xu cho câu trả lời đúng tiếp theo trong Nối từ hoặc Vua tiếng Việt.' },
  { id: 'mines_detector', type: 'consumable', name: 'Máy Dò Mìn', effect: 'mines_detector', rarity: 'rare', price: shopPrice(800), stackable: true, tradeable: true, description: 'Báo riêng vị trí một quả mìn chưa mở trong ván Dò mìn.' },
  { id: 'mines_safe_map', type: 'consumable', name: 'Bản Đồ An Toàn', effect: 'mines_safe_cell', rarity: 'rare', price: shopPrice(1000), stackable: true, tradeable: true, description: 'Chỉ ra riêng một ô an toàn chưa mở trong ván Dò mìn.' },
  { id: 'bet_insurance', type: 'consumable', name: 'Bảo Hiểm Cược', effect: 'bet_insurance', rarity: 'rare', price: shopPrice(1500), stackable: true, tradeable: true, description: 'Hoàn 25% nếu ván cược kế tiếp thua trắng; hiệu lực 24 giờ.' },
  { id: 'bet_insurance_plus', type: 'consumable', name: 'Bảo Hiểm Cược Cao Cấp', effect: 'bet_insurance_plus', rarity: 'epic', price: shopPrice(3500), stackable: true, tradeable: true, description: 'Hoàn 50% nếu ván cược kế tiếp thua trắng; hiệu lực 24 giờ.' },
  { id: 'hardcore_revive', type: 'consumable', name: 'Bùa Hồi Sinh', effect: 'hardcore_revive', rarity: 'epic', price: shopPrice(3000), stackable: true, tradeable: true, description: 'Hồi sinh một lần trong Hardcore Run; tối đa một lần mỗi run.' },
  { id: 'chest_lock', type: 'consumable', name: 'Khóa Hòm Hardcore', effect: 'hardcore_chest_lock', rarity: 'rare', price: shopPrice(1200), stackable: true, tradeable: true, description: 'Chặn một kết quả hòm rỗng hoặc vật phẩm giả trong Hardcore Run.' },
  { id: 'season_booster', type: 'consumable', name: 'Cờ Hiệu Mùa Giải', effect: 'season_points_boost', rarity: 'epic', price: shopPrice(2200), stackable: true, tradeable: true, description: 'Ba ván tiếp theo nhận gấp đôi điểm mùa.' },
  { id: 'streak_guard', type: 'consumable', name: 'Thẻ Giữ Chuỗi', effect: 'checkin_streak_guard', rarity: 'rare', price: shopPrice(900), stackable: true, tradeable: true, description: 'Bảo vệ chuỗi điểm danh khi bỏ lỡ đúng một ngày.' },
];

const COSMETICS = PROFILE_COSMETICS.map(item => ({
  ...item, rarity: item.rarity || 'rare', price: shopPrice(10000),
  shopEligible: !DEFAULT_PROFILE_ITEMS.has(item.id), stackable: false, tradeable: false,
  effect: 'profile_color', description: 'Đổi màu chủ đạo của thẻ /hoso.',
}));
const CATALOG = Object.freeze([...COSMETICS, ...UTILITY_ITEMS]);
const BY_ID = new Map(CATALOG.map(item => [item.id, item]));
function getCatalogItem(id) { return BY_ID.get(String(id)) || null; }
function listCatalog({ shopEligible = false } = {}) {
  return shopEligible ? CATALOG.filter(item => item.price > 0 && item.shopEligible !== false) : CATALOG;
}
module.exports = { DEFAULT_PRICE_MULTIPLIER, CATALOG, COSMETICS, UTILITY_ITEMS, getCatalogItem, listCatalog };
