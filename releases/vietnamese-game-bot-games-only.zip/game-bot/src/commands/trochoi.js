const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

function helpEmbed(prefix = process.env.COMMAND_PREFIX || '!') {
  return new EmbedBuilder().setColor(0x5865F2).setTitle('🎮 HƯỚNG DẪN TRÒ CHƠI')
    .setDescription('Các game hoạt động trong kênh riêng do quản trị viên thiết lập.')
    .addFields(
      { name: '🎲 Game đặt cược', value: [
        `• \`/baucua\` hoặc \`${prefix}baucua\` — bàn chung 30 giây`,
        `• \`/taixiu\` hoặc \`${prefix}taixiu\` — bàn Tài xỉu 30 giây`,
        `• \`/oantuti\` hoặc \`${prefix}oantuti <bua|keo|bao> <xu>\``,
        `• \`/blackjack\` hoặc \`${prefix}blackjack <xu>\``,
        `• \`/duangua\` hoặc \`${prefix}duangua\` — nhiều người cược trong 30 giây`,
        `• \`/mines\` hoặc \`${prefix}mines <xu> <số mìn>\``,
        `• \`/hardcore batdau\` hoặc \`${prefix}hardcore <xu> <class>\``,
      ].join('\n') },
      { name: '☠️ Hardcore Run', value: `• \`/hardcore hoso\` · \`/hardcore top\` · \`/hardcore rates\`\n• Tầng 100 là mốc hoàn thành; người chơi có thể tiếp tục Overrun tới tầng 999.` },
      { name: '🧠 Game trả lời trực tiếp', value: [
        `• \`/noitu batdau\` hoặc \`${prefix}noitu batdau\``,
        `• \`/noitu baotu\` · \`/noitu tudien\``,
        `• \`/vuatiengviet batdau\` hoặc \`${prefix}vuatiengviet batdau\``,
        'Nhập đáp án trực tiếp vào kênh. Bot chỉ phản hồi khi đúng.',
      ].join('\n') },
      { name: '💰 Xu và hồ sơ', value: '• `/xu sodu|daily|top|chuyen|lichsu`\n• `/hoso [user]`\n• `/anxin` — xin xu, yêu cầu có hiệu lực 30 giây' },
      { name: '🏪 Cửa hàng', value: '• `/shop xem` · `/buy`\n• `/inventory [user]` · `/use`\n• `/giftitem` — tặng vật phẩm hỗ trợ game' },
      { name: '📜 Tiến độ', value: '• `/nhiemvu xem|nhan|diemdanh`\n• `/xephang game|mua|nhan` — xếp hạng từng game và mùa' },
    ).setFooter({ text: `Prefix: ${prefix} • Không hiển thị lệnh quản trị` });
}
module.exports = {
  data: new SlashCommandBuilder().setName('trochoi').setDescription('Xem toàn bộ lệnh trò chơi dành cho người chơi'),
  helpEmbed,
  async execute(interaction) { return interaction.reply({ embeds: [helpEmbed()], flags: MessageFlags.Ephemeral }); },
};
