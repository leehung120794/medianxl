require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const { Client, Collection, Events, GatewayIntentBits, MessageFlags } = require('discord.js');
const pino = require('pino');

const commandNames = ['xu', 'hoso', 'baucua', 'oantuti', 'taixiu', 'blackjack', 'duangua', 'mines', 'hardcore', 'noitu', 'vuatiengviet', 'game', 'trochoi', 'shop', 'buy', 'inventory', 'use', 'giftitem', 'anxin', 'nhiemvu', 'xephang'];
const monitoring = require('./services/monitoringService');
const { startEconomyMaintenance } = require('./services/economyService');
const { handlePrefixMessage } = require('./services/prefixCommandService');
const { handleGameMessage } = require('./services/gameMessageService');
const { handleGamePrefix } = require('./services/gamePrefixService');
const { handleBetButton, handleBetModal, resumeOpenRounds } = require('./services/multiplayerGameService');
const { handleBlackjackButton } = require('./services/blackjackService');
const { handleHorseButton, handleHorseModal, resumeHorseRaces } = require('./services/horseRaceService');
const { handleMinesButton } = require('./services/minesService');
const { handleHardcoreButton, cleanupStaleHardcoreSessions } = require('./services/hardcoreService');
const { startTimedChallengeMaintenance } = require('./services/timedChallengeService');
const { handleCoinRequestButton } = require('./services/coinRequestService');
const { startCommerceMaintenance } = require('./services/commerceMaintenanceService');

if (!process.env.DISCORD_TOKEN) throw new Error('Missing DISCORD_TOKEN in .env');
const logDir = path.resolve(process.env.LOG_DIR || './logs');
fs.mkdirSync(logDir, { recursive: true });
const logger = pino({ level: process.env.LOG_LEVEL || 'info' }, pino.multistream([{ stream: process.stdout }, { stream: pino.destination({ dest: path.join(logDir, process.env.LOG_FILE_NAME || 'bot.log'), sync: false }) }]));
startEconomyMaintenance(logger);
const messageCommandsEnabled = /^(1|true|yes)$/i.test(process.env.ENABLE_MESSAGE_COMMANDS || process.env.ENABLE_PREFIX_COMMANDS || 'false');
const intents = [GatewayIntentBits.Guilds];
if (messageCommandsEnabled) intents.push(GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent);
const client = new Client({ intents });
client.commands = new Collection(commandNames.map(name => [name, require(`./commands/${name}`)]));

process.on('unhandledRejection', error => { logger.error({ err: error }, 'unhandled rejection'); monitoring.recordRuntimeError(error, { source: 'unhandledRejection' }); });
process.on('uncaughtException', error => { logger.fatal({ err: error }, 'uncaught exception'); monitoring.recordRuntimeError(error, { source: 'uncaughtException' }); });
client.once(Events.ClientReady, () => {
  const resumedRounds = resumeOpenRounds(client, logger);
  const resumedHorseRaces = resumeHorseRaces(client, logger);
  const expiredHardcoreRuns = cleanupStaleHardcoreSessions();
  startTimedChallengeMaintenance(client, logger);
  startCommerceMaintenance(client, logger);
  logger.info({ user: client.user.tag, resumedRounds, resumedHorseRaces, expiredHardcoreRuns }, 'game bot ready');
});
if (messageCommandsEnabled) client.on(Events.MessageCreate, message => {
  (async () => {
    if (await handlePrefixMessage(message, logger)) return;
    if (await handleGamePrefix(message)) return;
    await handleGameMessage(message);
  })().catch(error => { logger.error({ err: error }, 'message command failed'); monitoring.recordRuntimeError(error, { source: 'message' }); });
});
client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isButton() && interaction.customId.startsWith('anxin:')) return await handleCoinRequestButton(interaction);
    if (interaction.isButton() && interaction.customId.startsWith('hardcore:')) return await handleHardcoreButton(interaction);
    if (interaction.isButton() && interaction.customId.startsWith('mines:')) return await handleMinesButton(interaction);
    if (interaction.isButton() && interaction.customId.startsWith('horserace:')) return await handleHorseButton(interaction);
    if (interaction.isButton() && interaction.customId.startsWith('blackjack:')) return await handleBlackjackButton(interaction);
    if (interaction.isButton() && interaction.customId.startsWith('gamebet:')) return await handleBetButton(interaction);
    if (interaction.isModalSubmit() && interaction.customId.startsWith('horserace-modal:')) return await handleHorseModal(interaction);
    if (interaction.isModalSubmit() && interaction.customId.startsWith('gamebet-modal:')) return await handleBetModal(interaction);
    if (!interaction.isChatInputCommand()) return;
    const command = client.commands.get(interaction.commandName);
    if (!command) return interaction.reply({ content: 'Lệnh này không có trong phiên bản game bot.', flags: MessageFlags.Ephemeral });
    await command.execute(interaction);
  } catch (error) {
    logger.error({ err: error }, 'interaction failed');
    monitoring.recordRuntimeError(error, { source: 'interaction' });
    const payload = { content: 'Có lỗi khi xử lý lệnh.', flags: MessageFlags.Ephemeral };
    if (interaction.deferred || interaction.replied) await interaction.followUp(payload).catch(() => {});
    else await interaction.reply(payload).catch(() => {});
  }
});
client.login(process.env.DISCORD_TOKEN).catch(error => { logger.fatal({ err: error }, 'discord login failed'); process.exitCode = 1; });
