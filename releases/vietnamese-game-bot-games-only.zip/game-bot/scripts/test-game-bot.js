const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const testDb = path.resolve(__dirname, '../data/test-game-bot.sqlite');
process.env.DB_PATH = testDb;
const expectedCommands = ['xu', 'hoso', 'baucua', 'oantuti', 'taixiu', 'blackjack', 'duangua', 'mines', 'hardcore', 'noitu', 'vuatiengviet', 'game', 'trochoi', 'shop', 'buy', 'inventory', 'use', 'giftitem', 'anxin', 'nhiemvu', 'xephang'];

for (const name of expectedCommands) {
  const command = require(`../src/commands/${name}`);
  assert.equal(command.data.toJSON().name, name, `Sai schema command ${name}`);
}
const { GAMES } = require('../src/services/gameChannelService');
assert.deepEqual([...GAMES], ['noitu', 'baucua', 'oantuti', 'taixiu', 'blackjack', 'duangua', 'mines', 'hardcore', 'vuatiengviet']);
const { listCatalog } = require('../src/services/itemCatalogService');
const catalog = listCatalog();
assert(catalog.some(item => item.effect === 'hardcore_revive'));
assert(catalog.some(item => item.effect === 'mines_detector'));
assert(catalog.every(item => !['chest', 'material', 'collectible'].includes(item.type)));
const horse = require('../src/services/horseRaceService');
assert.equal(typeof horse.createHorseRace, 'function');
assert.equal(horse.ROUND_MS, 30_000);
assert.equal(horse.weightedWinner(0), 'sao_bang');
assert.equal(horse.weightedWinner(99), 'set_trang');
const hardcore = require('../src/services/hardcoreService');
assert.equal(typeof hardcore.startHardcore, 'function');
assert.equal(hardcore.COMPLETION_FLOOR, 100);
assert.equal(hardcore.MAX_FLOOR, 999);
assert(hardcore.defenseReduction(100, 10) > 0 && hardcore.defenseReduction(100, 10) < 0.75);
const fun = require('../src/services/funGameService');
const vua = fun.startVuaSession('test-guild', { forceHard: false, now: 1 });
assert(vua.question.answer && vua.question.mixed);
fun.endVuaSession('test-guild');
const { db } = require('../src/db');
db.close();
for (const suffix of ['', '-wal', '-shm']) fs.rmSync(`${testDb}${suffix}`, { force: true });
console.log(JSON.stringify({ ok: true, commands: expectedCommands.length, games: GAMES.length, shopItems: catalog.length }));
