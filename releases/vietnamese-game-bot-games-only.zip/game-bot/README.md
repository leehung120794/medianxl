# Vietnamese Discord Game Bot

Phiên bản bot độc lập chỉ dành cho trò chơi và hệ thống xu. Không cần dữ liệu item hay dịch vụ đồng bộ bên ngoài.

## Trò chơi

- Bầu cua, Tài xỉu, Oẳn tù tì
- Blackjack, Đua ngựa nhiều người, Dò mìn
- Nối từ, Vua tiếng Việt
- Hardcore Run

## Cài đặt

1. Cài Node.js 18.17 trở lên.
2. Giải nén và chạy `npm install`.
3. Sao chép `.env.example` thành `.env`, sau đó điền token và ID Discord.
4. Chạy `npm run register` để đăng ký slash command cho server.
5. Chạy `npm start`.

Bot cần bật **Message Content Intent** trong Discord Developer Portal nếu muốn dùng prefix command và trả lời trực tiếp trong Nối từ/Vua tiếng Việt.

## Thiết lập kênh

Dùng `/game set` để đặt kênh riêng cho từng game. Đua ngựa là bàn chung nhiều người và nhận cược trong 30 giây. Hardcore Run là game cá nhân có cược, trang bị hỗ trợ và bảng xếp hạng tầng.

Các lệnh thông thường có trong `/trochoi`. Quản trị viên có thể dùng `/game`, `/shop` và các prefix command quản trị để cấu hình kênh, phần thưởng, giới hạn cược, shop và xu.

SQLite được tạo tự động tại `data/game-bot.sqlite`. Hãy sao lưu file này định kỳ khi bot đã đưa vào sử dụng.
